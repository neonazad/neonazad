// Example script for interactivity
function showAlert() {
  alert('Thank you for visiting the official Cristiano Ronaldo website!');
}